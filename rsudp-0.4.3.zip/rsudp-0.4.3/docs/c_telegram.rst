:py:data:`rsudp.c_telegram` (Telegram alerts)
=====================================================

.. automodule:: rsudp.c_telegram
    :members:

................

* :ref:`genindex`
* :ref:`search`
.. * :ref:`modindex`

`Back to top ↑ <#top>`_
